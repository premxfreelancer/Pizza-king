function ccc() {

 var text = "Name:- Classic Cheese pizza";
      
  window.location.href = "dilivery.html?text=" + encodeURIComponent(text);
    }
 
 function ccc2() {

 var text = "Name:- Homemade Prpporoni Pizza";
      
  window.location.href = "dilivery.html?text=" + encodeURIComponent(text);
    }
  
  function ccc3() {

 var text = "Name:- Chinese special pizza";
      
  window.location.href = "dilivery.html?text=" + encodeURIComponent(text);
    }
  
  
  function ccc4() {

 var text = "heart pizza";
      
  window.location.href = "dilivery.html?text=" + encodeURIComponent(text);
    }

  function bbb() {

 var text = "Name:- Hamburger";
      
  window.location.href = "dilivery.html?text=" + encodeURIComponent(text);
    }
  
  function bbb2() {

 var text = "Name:- the perfact basic burger";
      
  window.location.href = "dilivery.html?text=" + encodeURIComponent(text);
    }
  
  
  function bbb3() {

 var text = "Name:- stovtop burgers";
      
  window.location.href = "dilivery.html?text=" + encodeURIComponent(text);
    }
  
  
  